import numpy as np
import matplotlib.pyplot as plt

class MLP():
    """
    Create a two-layer perceptron.

    train_data: A Nx2 matrix with the input data.

    target: A Nx1 matrix with expected outputs

    lr: the learning rate. Defaults to 0.1

    num_epochs: the number of times the training data goes through the model
        while training

    num_input: the number of nodes in the input layer of the MLP.
        Should be equal to the second dimension of train_data.

    num_hidden: the number of nodes in the hidden layer of the MLP.

    num_output: the number of nodes in the output layer of the MLP.
        Should be equal to the second dimension of target.
    """

    def __init__(self, train_data, target, lr=0.1, num_epochs=100, num_input=2, num_hidden=2, num_output=1):
        self.train_data = train_data
        self.target = target
        self.lr = lr
        self.num_epochs = num_epochs

        # initialize both sets of weights and biases randomly
        # - weights_01: weights between input and hidden layer
        # - weights_12: weights between hidden and output layer
        self.weights_01 = np.random.uniform(size=(num_input, num_hidden))
        self.weights_12 = np.random.uniform(size=(num_hidden, num_output))

        # - b01: biases for the  hidden layer
        # - b12: bias for the output layer
        self.b01 = np.random.uniform(size=(1, num_hidden))
        self.b12 = np.random.uniform(size=(1, num_output))

        self.losses = []

    def update_weights_batch(self):

        # Calculate the squared error
        loss = 0.5 * (self.target - self.output_final) ** 2
        #print(loss)
        self.losses.append(np.sum(loss))

        error_term = self.output_final - self.target

        # the gradient for the hidden layer weights
        grad01 = -self.train_data.T @ (
                    ((error_term * self._delsigmoid(self.output_final)) * self.weights_12.T) * self._delsigmoid(self.hidden_out))
        #print("grad01: ", grad01)
        #print(grad01.shape)

        # the gradient for the output layer weights
        grad12 = -self.hidden_out.T @ (error_term * self._delsigmoid(self.output_final))

        #print("grad12: ", grad12)
        #print(grad12.shape)

        # updating the weights by the learning rate times their gradient
        self.weights_01 += self.lr * grad01
        self.weights_12 += self.lr * grad12

        # update the biases the same way
        self.b01 += np.sum(
            -self.lr * ((error_term * self._delsigmoid(self.output_final)) * self.weights_12.T) * self._delsigmoid(
                self.hidden_out), axis=0)
        self.b12 += np.sum(-self.lr * error_term * self._delsigmoid(self.output_final), axis=0)

    def update_weights_online(self, i):
        '''
        :param i: the ith sample in dataset
        '''

        # Calculate the squared error
        loss = 0.5 * (self.target - self.output_final) ** 2
        #print(loss)
        self.losses.append(np.sum(loss))

        error_term = self.output_final - self.target[i]
        #print("error_term: ", error_term)
        #print("self._delsigmoid(self.hidden_out): ", self._delsigmoid(self.hidden_out))
        #print("self._delsigmoid(self.output_final): ", self._delsigmoid(self.output_final))
        #print("self.weights_12.T: ", self.weights_12.T)

        # the gradient for the hidden layer weights
        grad01 = -self.train_data[i,:].reshape(-1,1) @ (
                    ((error_term * self._delsigmoid(self.output_final)) * self.weights_12.T) * self._delsigmoid(self.hidden_out))
        #print("grad01: ", grad01)
        #print(grad01.shape)

        # the gradient for the output layer weights
        grad12 = -self.hidden_out.T @ (error_term * self._delsigmoid(self.output_final))

        #print("grad12: ", grad12)
        #print(grad12.shape)

        # updating the weights by the learning rate times their gradient
        self.weights_01 += self.lr * grad01
        self.weights_12 += self.lr * grad12

        # update the biases the same way
        self.b01 += np.sum(
            -self.lr * ((error_term * self._delsigmoid(self.output_final)) * self.weights_12.T) * self._delsigmoid(
                self.hidden_out), axis=0)
        self.b12 += np.sum(-self.lr * error_term * self._delsigmoid(self.output_final), axis=0)

    def _sigmoid(self, x):
        """
        The sigmoid activation function.
        """
        return 1 / (1 + np.exp(-x))

    def _delsigmoid(self, x):
        """
        The first derivative of the sigmoid function wrt x
        """
        return x * (1 - x)

    def forward(self, batch):
        """
        A single forward pass through the network.
        Implementation of wX + b
        """

        self.hidden_ = np.dot(batch, self.weights_01) + self.b01
        self.hidden_out = self._sigmoid(self.hidden_)

        self.output_ = np.dot(self.hidden_out, self.weights_12) + self.b12
        self.output_final = self._sigmoid(self.output_)

        return self.output_final

    def classify(self, datapoint):
        """
        Return the class to which a datapoint belongs based on
        the MLP's output for that point.
        """
        datapoint = np.transpose(datapoint)
        if self.forward(datapoint) >= 0.5:
            return 1

        return 0

    def train_batch(self):
        """
        Train an MLP. Runs through the data num_epochs number of times.
        A forward pass is done first, followed by a backward pass (backpropagation)
        where the networks parameter's are updated.
        """
        for _ in range(self.num_epochs):
            self.forward(self.train_data)
            self.update_weights_batch()

    def train_online(self):
        """
        Train an MLP. Runs through one sample per time.
        A forward pass is done first, followed by a backward pass (backpropagation)
        where the networks parameter's are updated.
        """
        sample_num = self.train_data.shape[0]

        for c in range(self.num_epochs):
            for i in range(sample_num):
                self.forward(self.train_data[i,:])
                self.update_weights_online(i)
            print('training epochs: ', c)

    def get_losses(self):
        return self.losses

if __name__ == "__main__":
    # dataset generation
    data_max = 5
    data_min = -5
    sample_num = 400
    data_input = np.random.uniform(low=data_min, high=data_max, size=(sample_num, 2))
    data_true_class = np.zeros((sample_num, 1))

    boundary_line = data_input[:, 1] - 2.5 * np.sin(2.0*np.pi/5.0*data_input[:, 0])
    data_true_class[boundary_line > 0] = 1
    data_true_class[boundary_line <= 0] = 0

    data_predict_class = np.zeros((sample_num, 1))

    mlp = MLP(data_input, data_true_class, lr=0.01, num_epochs=15000, num_hidden=12)
    mlp.train_batch()
    #mlp.train_online()

    # plot result
    fig, ax = plt.subplots(figsize=(12, 6))
    true_class1, = ax.plot([], [], 'ro', label="true_class1")
    true_class2, = ax.plot([], [], 'go', label="true_class2")
    predict_class1, = ax.plot([], [], 'r*', label="predict_class1")
    predict_class2, = ax.plot([], [], 'g*', label="predict_class2")
    true_line, = plt.plot([], [], 'b--', label='True line')
    predict_line, = plt.plot([], [], 'c--', label='Predict line')


    sample_num = data_input.shape[0]

    for i in range(sample_num):
        data_predict_class[i] = mlp.classify(data_input[i,:])

        if data_true_class[i] == 1:
            true_class1, = plt.plot(data_input[i, 0], data_input[i, 1], 'ro', label='True class 1')
        else:
            true_class2, = plt.plot(data_input[i, 0], data_input[i, 1], 'go', label='True class 2')

        if data_predict_class[i] == 1:
            predict_class1, = plt.plot(data_input[i, 0], data_input[i, 1], 'r*', label='Predict class 1')
        else:
            predict_class2, = plt.plot(data_input[i, 0], data_input[i, 1], 'g*', label='Predict class 2')

    true_line_x = np.arange(data_min,data_max,0.2)
    true_line_y = 2.5 * np.sin(2.0 * np.pi / 5.0 * true_line_x)

    true_line, = plt.plot(true_line_x, true_line_y, 'b--', label='True line')

    #calculate boundary line of the MLP
    data_x = np.linspace(data_min, data_max, num=200)
    data_y = np.linspace(data_min, data_max, num=500)
    boundary_points = []
    for i in range(len(data_x)):
        for j in range(len(data_y)):
            data_test = np.array([[data_x[i],data_y[j]]])
            data_test_predict = mlp.forward(data_test)
            if abs(data_test_predict-0.5)<0.02:
                boundary_points.append(data_test.reshape(-1).tolist())
                #print(data_test.tolist())

    boundary_points = np.array(boundary_points)
    #print(boundary_points.shape)
    predict_line, = plt.plot(boundary_points[:,0], boundary_points[:,1], 'c--', label='Predict line')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.xlim([-5, 5])
    plt.ylim([-5, 5])
    plt.legend(handles=[true_class1, true_class2, predict_class1, predict_class2, true_line, predict_line], \
               loc='upper center', bbox_to_anchor=(0.4, 1.1), ncol=3)
    plt.show()




    plt.figure(2)
    losses = mlp.get_losses()
    plt.plot(losses, 'b-')
    plt.yscale('log')
    plt.show()