import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

#https://developpaper.com/perceptron-tutorial-implementation-and-visual-examples/
class perceptron():
    def __init__(self, N=2, alpha=0.1):
        '''
        :param N: number of perceptron input
        :param alpha: learning rate
        '''
        self.N = N
        self.alpha = alpha
        self.bias = -1
        self.W = np.random.rand(N+1) # one for bias weight

        self.W_list = []
        self.W_list.append(self.W)


    def forward(self, input):
        '''
        :param input: a Nby1 2D array, not include bias
        '''
        assert input.size==self.N, 'input size error, no need bias'

        X = np.insert(input, 0, self.bias)
        g = np.dot(X, self.W)
        if g>=0:
            return 1
        else:
            return -1

    def train(self, dataset, n_iter=100):
        '''
        :param
        dataset: N by 3, for each row = x pos, y pos, class label
        :return: trained weights
        '''
        n_samples = dataset.shape[0]

        bias_vector = np.ones((sample_num, 1)) * self.bias
        X = np.hstack((bias_vector, dataset))

        for i in range(n_iter):
            for j in range(n_samples):
                if X[j, -1] * np.dot(self.W, X[j, :-1]) <= 0:
                    self.W += X[j, -1] * X[j, :-1]

            self.W_list.append(self.W.copy())

    def train1(self, dataset, n_iter=100):
        '''
        :param
        dataset: N by 3, for each row = x pos, y pos, class label
        :return: trained weights
        '''
        n_samples = dataset.shape[0]

        bias_vector = np.ones((sample_num, 1)) * self.bias
        X = np.hstack((bias_vector, dataset))

        for i in range(n_iter):
            for j in range(n_samples):
                y= self.forward(X[j,1:-1]) #predicted value
                self.W += self.alpha* X[j,:-1] * ((X[j,-1])-y) #X[j, -1] * X[j, :-1]

            self.W_list.append(self.W.copy())

    def print_weight(self):
        print('Weight: ', self.W)

    def get_weight(self):
        return self.W

    def get_weight_list(self):
        return self.W_list

    def set_weight(self, w):
        self.W = w


#####################global variables
binary_classifier = perceptron(alpha=0.05)

# dataset generation
sample_num = 50
training_iteration = 100
data_input = np.random.uniform(low=0, high=5, size=(sample_num, 2))
data_true_class = np.zeros((sample_num,1))

base_line = 0.5 * data_input[:, 0] - 1.0 * data_input[:, 1] + 0.5
data_true_class[base_line>=0] = 1
data_true_class[base_line < 0] = -1

data_class1 = data_input[data_true_class.reshape(-1)==1, :]
data_class2 = data_input[data_true_class.reshape(-1)==-1, :]


dataset = np.hstack((data_input, data_true_class))

data_predict_class = np.zeros((sample_num, 1))

#binary_classifier.batch_train(dataset, batch_num=10, episode=1000)
#binary_classifier.train(dataset, n_iter=200)

binary_classifier.train1(dataset, n_iter=training_iteration)
weight_list = binary_classifier.get_weight_list()


binary_classifier.print_weight()


# for animation and plot
fig, ax = plt.subplots(figsize=(12, 6))
true_class1, = ax.plot([], [], 'ro', label="true_class1")
true_class2, = ax.plot([], [], 'go', label="true_class2")
predict_class1, = ax.plot([], [], 'r*', label="predict_class1")
predict_class2, = ax.plot([], [], 'g*', label="predict_class2")
true_line, = plt.plot([], [], 'b--', label='True line')
predict_line, = plt.plot([], [], 'c--', label='Predict line')


def update_animation(i):
    '''
    :param i: i's frame for animation
    '''
    ax.cla()  # Clear ax
    true_class1, = plt.plot(data_class1[:, 0], data_class1[:, 1], 'ro', label='True class 1')
    true_class2, = plt.plot(data_class2[:, 0], data_class2[:, 1], 'go', label='True class 2')
    binary_classifier.set_weight(weight_list[i])
    for j in range(sample_num):

        data_predict_class[j] = binary_classifier.forward(dataset[j,:-1])
        if data_predict_class[j] == 1:
            predict_class1, = plt.plot(data_input[j, 0], data_input[j, 1], 'r*', label='Predict class 1')
        else:
            predict_class2, = plt.plot(data_input[j, 0], data_input[j, 1], 'g*', label='Predict class 2')

    true_line, = plt.plot([0, 5], [0.5, 3], 'b--', label='True line')
    W = binary_classifier.get_weight()
    predict_line, = plt.plot([0, 5], [W[0] / W[2], (W[0] - 5 * W[1]) / W[2]], 'c--', label='Predict line')

    plt.xlabel('x')
    plt.ylabel('y')
    plt.xlim([0, 5])
    plt.ylim([0, 5])
    plt.legend(handles=[true_class1, true_class2, predict_class1, predict_class2, true_line, predict_line],
               loc='upper center', bbox_to_anchor=(0.4, 1.1), ncol=3)


# FuncAnimation will call the 'update' function for each frame; here
# animating over 10 frames, with an interval of 200ms between frames.
anim = FuncAnimation(fig, update_animation, frames=range(0,training_iteration+1), interval=200, repeat=False)

#anim.save("2D linear classifier.gif", writer="imagemagick")
plt.show()
plt.close()

#plot result
plt.figure(2)


for i in range(sample_num):
    if data_true_class[i] == 1:
        true_class1, = plt.plot(data_input[i, 0],data_input[i, 1], 'ro', label='True class 1')
    else:
        true_class2, = plt.plot(data_input[i, 0],data_input[i, 1], 'go', label='True class 2')

    if data_predict_class[i] == 1:
        predict_class1, = plt.plot(data_input[i, 0],data_input[i, 1], 'r*', label='Predict class 1')
    else:
        predict_class2, = plt.plot(data_input[i, 0],data_input[i, 1], 'g*', label='Predict class 2')

true_line, = plt.plot([0, 5], [0.5, 3], 'b--', label='True line')
W=binary_classifier.get_weight()
predict_line, = plt.plot([0, 5], [W[0]/W[2], (W[0]-5*W[1])/W[2]], 'c--', label='Predict line')
plt.xlabel('x')
plt.ylabel('y')
plt.xlim([0,5])
plt.ylim([0, 5])
plt.legend(handles=[true_class1, true_class2, predict_class1, predict_class2, true_line, predict_line],\
           loc='upper center', bbox_to_anchor=(0.4, 1.1), ncol=3)
plt.show()