import numpy as np

class perceptron():
    def __init__(self, N=2, alpha=0.1):
        '''
        :param N: number of perceptron imput
        :param alpha: learning rate
        '''
        self.N = N
        self.alpha = alpha
        self.bias = -1
        self.W = np.random.rand(N+1) # one for bias weight


    def forward(self, input):
        '''
        :param input: a Nby1 2D array, not include bias
        '''
        assert input.size==self.N, 'input size error, no need bias'

        X = np.insert(input, 0, self.bias)
        g = np.dot(X, self.W)
        if g>=0:
            return 1
        else:
            return 0

    # def batch_forward(self, inputs):
    #     '''
    #     :param inputs: a M by N array, N is NN's input number
    #     '''
    #     assert inputs.shape[1]==self.N, 'inputs size error, no need bias'
    #     bias_vector = np.ones((self.N ,1))*self.bias
    #     X = np.hstack((bias_vector,inputs))
    #
    #     return np.dot(X, self.W)


    def batch_train(self, dataset, episode=10):
        '''
        :param dataset: logic operation truth table 4 by 3
        :return: trained weights
        '''
        assert dataset.shape[1]==self.N + 1, 'inputs size error'

        sample_num = dataset.shape[0]

        bias_vector = np.ones((sample_num, 1)) * self.bias
        X = np.hstack((bias_vector, dataset))

        e = 1
        for e in range(episode):
            delt_W = None
            for i in range(sample_num):
                y=self.forward(X[i,1:-1])

                if delt_W is None:
                    delt_W = self.alpha* X[i,:-1] * (X[i,-1]-y)
                else:
                    delt_W += self.alpha * X[i, :-1] * (X[i, -1] - y)

            self.W += delt_W

    def print_weight(self):
        print('Weight: ', self.W)

if __name__ == "__main__":
    perceptron_AND = perceptron()
    AND_data = np.array([
        [0, 0, 0],
        [0, 1, 0],
        [1, 0, 0],
        [1, 1, 1],
    ])
    perceptron_AND.batch_train(AND_data, episode=5)

    sample_num = AND_data.shape[0]
    for i in range(sample_num):
        print('AND input: ', AND_data[i,:-1],
              'desire output:', AND_data[i,-1],
              'actual output:', perceptron_AND.forward(AND_data[i,:-1]))
    perceptron_AND.print_weight()

    print('=================================')

    perceptron_OR = perceptron()
    OR_data = np.array([
        [0, 0, 0],
        [0, 1, 1],
        [1, 0, 1],
        [1, 1, 1],
    ])
    perceptron_OR.batch_train(OR_data, episode=5)

    sample_num = OR_data.shape[0]
    for i in range(sample_num):
        print('OR input: ', OR_data[i, :-1],
              'desire output:', OR_data[i, -1],
              'actual output:', perceptron_OR.forward(OR_data[i, :-1]))
    perceptron_OR.print_weight()

    print('=================================')

    perceptron_XOR = perceptron()
    XOR_data = np.array([
        [0, 0, 0],
        [0, 1, 1],
        [1, 0, 1],
        [1, 1, 0],
    ])
    perceptron_XOR.batch_train(XOR_data, episode=100)

    sample_num = XOR_data.shape[0]
    for i in range(sample_num):
        print('XOR input: ', XOR_data[i, :-1],
              'desire output:', XOR_data[i, -1],
              'actual output:', perceptron_OR.forward(XOR_data[i, :-1]))
    perceptron_XOR.print_weight()
